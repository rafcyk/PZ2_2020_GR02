﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace SpaceShooter
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        //Teksturki
        Texture2D playerTexture;
        Texture2D startButtonTexture;
        Texture2D exitButtonTexture;

        //Punkty odniesienia
        Vector2 startButtonPosition;
        Vector2 exitButtonPosition;
        Vector2 playerPosition;

        //niewidoczne pola do wykrycia kolizji z przyciskami
        Rectangle startRectangle;
        Rectangle exitRectangle;

        float playerSpeed;


        //enum odpowiadający za stan gry - coś jak bool tylko rozbudowany
        enum GameState
        {
            MainMenu,
            GamePlay,
            EndOfGame,
        }
        GameState _state;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            playerPosition = new Vector2(graphics.PreferredBackBufferWidth / 2, graphics.PreferredBackBufferHeight);
            startButtonPosition = new Vector2(graphics.PreferredBackBufferWidth / 2, graphics.PreferredBackBufferHeight/2);
            exitButtonPosition = new Vector2(graphics.PreferredBackBufferWidth / 2, graphics.PreferredBackBufferHeight / 2 + 100);

            playerSpeed = 300f;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            playerTexture = Content.Load<Texture2D>("SpaceShip");
            startButtonTexture = Content.Load<Texture2D>("StartButton");
            exitButtonTexture = Content.Load<Texture2D>("exitButton");
        }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        //Update określa którego podupdate wywołać - np aktualizującego stan gry albo odpowiadającego za zakończenie
        protected override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            switch (_state)
            {
                case GameState.MainMenu:
                    UpdateMainMenu(gameTime);
                    break;
                case GameState.GamePlay:
                    UpdateGameplay(gameTime);
                    break;
                case GameState.EndOfGame:
                    UpdateEndOfGame(gameTime);
                    break;
            }
        }
        
        void UpdateMainMenu(GameTime deltaTime)
        {
            var mouseState = Mouse.GetState();
            var mousePosition = new Point(mouseState.X, mouseState.Y);
            if (startRectangle.Contains(mousePosition) && mouseState.LeftButton == ButtonState.Pressed) _state = GameState.GamePlay;
            else if (exitRectangle.Contains(mousePosition) && mouseState.LeftButton == ButtonState.Pressed) Exit();
        }

        void UpdateGameplay(GameTime gameTime)
        {
            var kstate = Keyboard.GetState();

            if (kstate.IsKeyDown(Keys.Left)) playerPosition.X -= playerSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (kstate.IsKeyDown(Keys.Right)) playerPosition.X += playerSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;

            //Moving out of corners
            if (playerPosition.X > graphics.PreferredBackBufferWidth - playerTexture.Width / 2) playerPosition.X = graphics.PreferredBackBufferWidth - playerTexture.Width / 2;
            else if (playerPosition.X < playerTexture.Width / 2) playerPosition.X = playerTexture.Width / 2;

            //Escape podczas rozgrywki
            if (Keyboard.GetState().IsKeyDown(Keys.Escape)) _state = GameState.EndOfGame;
            //if (playerDied)
            //    _state = GameState.EndOfGame;
        }

        void UpdateEndOfGame(GameTime deltaTime)
        {
            // Update scores
            // Do any animations, effects, etc for getting a high score
            // Respond to user input to restart level, or go back to main menu
            //if (pushedMainMenuButton)
            //    _state = GameState.MainMenu;
            //else if (pushedRestartLevelButton)
            //{
            //    ResetLevel();
            //    _state = GameState.GamePlay;
            //}
            if (Keyboard.GetState().IsKeyDown(Keys.Escape)) _state = GameState.MainMenu;
        }

        //DRAW - switch określa ktorą podkategorie Draw wywołać - co rysować 
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            base.Draw(gameTime);
            switch (_state)
            {
                case GameState.MainMenu:
                    DrawMainMenu(gameTime);
                    break;
                case GameState.GamePlay:
                    DrawGameplay(gameTime);
                    break;
                case GameState.EndOfGame:
                    DrawEndOfGame(gameTime);
                    break;
            }
        }

        void DrawMainMenu(GameTime deltaTime)
        {
            startRectangle = new Rectangle(
                (graphics.PreferredBackBufferWidth / 2 - startButtonTexture.Width / 2),
                (graphics.PreferredBackBufferHeight / 2 - startButtonTexture.Height / 2),
                (startButtonTexture.Width),
                (startButtonTexture.Height));

            exitRectangle = new Rectangle(
                (graphics.PreferredBackBufferWidth / 2 - startButtonTexture.Width / 2),
                (graphics.PreferredBackBufferHeight / 2 - startButtonTexture.Height / 2 + 100),
                (exitButtonTexture.Width),
                (exitButtonTexture.Height));

            this.IsMouseVisible = true;

            spriteBatch.Begin();
            spriteBatch.Draw(startButtonTexture, startButtonPosition, null, Color.White, 0f, new Vector2(startButtonTexture.Width/2, startButtonTexture.Height/2), Vector2.One, SpriteEffects.None, 0f);
            spriteBatch.Draw(exitButtonTexture, exitButtonPosition, null, Color.White, 0f, new Vector2(exitButtonTexture.Width / 2, exitButtonTexture.Height/2), Vector2.One, SpriteEffects.None, 0f);
            spriteBatch.End();
        }

        void DrawGameplay(GameTime deltaTime)
        {
            this.IsMouseVisible = false;
            spriteBatch.Begin();
            spriteBatch.Draw(playerTexture, playerPosition, null, Color.White, 0f, new Vector2(playerTexture.Width / 2, playerTexture.Height), Vector2.One, SpriteEffects.None, 0f);
            spriteBatch.End();
        }

        void DrawEndOfGame(GameTime deltaTime)
        {
            // Draw text and scores
            // Draw menu for restarting level or going back to main menu
        }
    }
}
